<?php

session_start();
include "config.php";

$error = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    verify_csrf();

    $username = trim($_POST["username"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($username === "" || $password === "") {

        $error = "Please enter your username and password.";

    } else {

        $stmt = $conn->prepare(
            "SELECT id, username, password
             FROM admins
             WHERE username = ?
             LIMIT 1"
        );

        $stmt->bind_param("s", $username);
        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows === 1) {

            $admin = $result->fetch_assoc();

            if (password_verify($password, $admin["password"])) {

                session_regenerate_id(true);

                $_SESSION["admin"] = $admin["username"];
                $_SESSION["admin_id"] = $admin["id"];

                header("Location: dashboard.php");
                exit();

            } else {

                $error = "Invalid username or password.";

            }

        } else {

            $error = "Invalid username or password.";

        }

        $stmt->close();
    }
}

$conn->close();

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Admin Login | Wallance Hotel</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #0f4c75;
}

.login {
    width: 90%;
    max-width: 400px;
    background: white;
    margin: 100px auto;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 10px 30px rgba(0,0,0,.2);
}

h2 {
    color: #0f4c75;
    text-align: center;
}

input {
    width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #ddd;
    border-radius: 6px;
}

button {
    width: 100%;
    padding: 12px;
    margin-top: 10px;
    background: #3282b8;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

button:hover {
    background: #0f4c75;
}

.error {
    color: #b00020;
    text-align: center;
}

</style>

</head>

<body>

<div class="login">

<h2>Wallance Hotel Admin</h2>

<?php if ($error !== ""): ?>

<p class="error">
    <?php echo htmlspecialchars($error); ?>
</p>

<?php endif; ?>

<form method="POST">

<input
    type="hidden"
    name="csrf_token"
    value="<?php echo e(csrf_token()); ?>"
>

<input
    type="text"
    name="username"
    placeholder="Username"
    required
    autocomplete="username"
>

<input
    type="password"
    name="password"
    placeholder="Password"
    required
    autocomplete="current-password"
>

<button type="submit">
    Login
</button>

</form>

</div>

</body>

</html>