<?php
include "config.php";

$sql = "SELECT id, room_name, room_type, price
        FROM rooms
        WHERE status = 'Available'
        ORDER BY price ASC";

$result = $conn->query($sql);

if (!$result) {
    die("Unable to load rooms.");
}
?>

<?php if ($result->num_rows > 0): ?>

    <?php while ($room = $result->fetch_assoc()): ?>

        <option value="<?php echo (int)$room['id']; ?>">
            <?php echo htmlspecialchars($room['room_name']); ?>
            -
            ₦<?php echo number_format($room['price'], 2); ?>
            / night
        </option>

    <?php endwhile; ?>

<?php else: ?>

    <option value="">No rooms currently available</option>

<?php endif; ?>

<?php
$conn->close();
?>