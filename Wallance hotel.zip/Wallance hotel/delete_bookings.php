<?php

session_start();

include "config.php";


/*
|--------------------------------------------------------------------------
| ADMIN AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION["admin"])) {

    header("Location: login.php");

    exit();
}


/*
|--------------------------------------------------------------------------
| ONLY POST REQUESTS ARE ALLOWED
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    die("Method not allowed.");
}


/*
|--------------------------------------------------------------------------
| CSRF PROTECTION
|--------------------------------------------------------------------------
*/

verify_csrf();


/*
|--------------------------------------------------------------------------
| GET BOOKING ID
|--------------------------------------------------------------------------
*/

$booking_id =
    (int)($_POST["booking_id"] ?? 0);


if ($booking_id <= 0) {

    die("Invalid booking ID.");
}


/*
|--------------------------------------------------------------------------
| DELETE BOOKING
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare(
    "DELETE FROM bookings
     WHERE id = ?"
);

$stmt->bind_param(
    "i",
    $booking_id
);


if (!$stmt->execute()) {

    error_log(
        "Unable to delete booking: " .
        $stmt->error
    );

    $stmt->close();
    $conn->close();

    die(
        "Unable to delete booking."
    );
}


$stmt->close();
$conn->close();


/*
|--------------------------------------------------------------------------
| RETURN TO BOOKINGS
|--------------------------------------------------------------------------
*/

header(
    "Location: view_bookings.php"
);

exit();

?>