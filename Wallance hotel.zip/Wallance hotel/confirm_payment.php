<?php

session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

include "config.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    http_response_code(405);

    die("Method not allowed.");
}

verify_csrf();

$booking_id = (int)($_POST["booking_id"] ?? 0);

if ($booking_id <= 0) {
    die("Invalid booking.");
}

$stmt = $conn->prepare(
    "SELECT payment_status, payment_reference
     FROM bookings
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $booking_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    die("Booking not found.");
}

$booking = $result->fetch_assoc();

$stmt->close();

if ($booking["payment_status"] === "Paid") {
    die("This booking has already been paid.");
}

if (empty($booking["payment_reference"])) {
    die("The customer has not submitted a payment reference yet.");
}

$stmt = $conn->prepare(
    "UPDATE bookings
     SET
        payment_status = 'Paid',
        booking_status = 'Confirmed'
     WHERE id = ?"
);

$stmt->bind_param("i", $booking_id);

if ($stmt->execute()) {

    header("Location: view_bookings.php");
    exit();

}

die("Unable to confirm payment.");

?>