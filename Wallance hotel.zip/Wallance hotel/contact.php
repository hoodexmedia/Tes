<?php

include "config.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: Wallance.html#contact");
    exit();
}

$name = trim($_POST["name"] ?? "");
$email = trim($_POST["email"] ?? "");
$subject = trim($_POST["subject"] ?? "");
$message = trim($_POST["message"] ?? "");

if (
    $name === "" ||
    !filter_var($email, FILTER_VALIDATE_EMAIL) ||
    $message === ""
) {
    die("Please complete all required fields correctly.");
}

$stmt = $conn->prepare(
    "INSERT INTO contacts
    (name, email, subject, message)
    VALUES (?, ?, ?, ?)"
);

$stmt->bind_param(
    "ssss",
    $name,
    $email,
    $subject,
    $message
);

if (!$stmt->execute()) {
    die("Unable to send your message. Please try again.");
}

$stmt->close();
$conn->close();

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Message Sent | Wallance Hotel</title>

<style>

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f5f7f9;
}

.box {
    width: 90%;
    max-width: 550px;
    margin: 80px auto;
    background: white;
    padding: 40px;
    text-align: center;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0,0,0,.1);
}

h1 {
    color: #0f4c75;
}

a {
    display: inline-block;
    margin-top: 20px;
    padding: 12px 20px;
    background: #0f4c75;
    color: white;
    text-decoration: none;
    border-radius: 6px;
}

</style>

</head>

<body>

<div class="box">

<h1>Message Sent</h1>

<p>
Thank you for contacting Wallance Hotel.
</p>

<p>
Your message has been received successfully.
</p>

<a href="Wallance.html">
    Return to Website
</a>

</div>

</body>

</html>