<?php

session_start();
include "config.php";

$booking_id = (int)($_GET["booking_id"] ?? 0);

if ($booking_id <= 0) {
    die("Invalid booking.");
}

/*
 * Only allow access to a booking that this session created.
 * booking.php sets $_SESSION["booking_ids"][] right after insert.
 */
if (
    empty($_SESSION["booking_ids"]) ||
    !in_array($booking_id, $_SESSION["booking_ids"], true)
) {
    die("You do not have access to this booking.");
}

$stmt = $conn->prepare("
    SELECT
        b.id,
        b.guest_name,
        b.email,
        b.payment_status,
        b.payment_reference,
        r.room_name,
        r.price,
        b.check_in,
        b.check_out
    FROM bookings b
    INNER JOIN rooms r ON b.room_id = r.id
    WHERE b.id = ?
");

$stmt->bind_param("i", $booking_id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    die("Booking not found.");
}

$booking = $result->fetch_assoc();

$stmt->close();

/* Calculate number of nights */
$check_in = new DateTime($booking["check_in"]);
$check_out = new DateTime($booking["check_out"]);

$nights = $check_in->diff($check_out)->days;

if ($nights < 1) {
    die("Invalid booking dates.");
}

$total_amount = $booking["price"] * $nights;

$conn->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Payment | Wallance Hotel</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f5f7f9;
    color: #333;
}

.container {
    width: 90%;
    max-width: 700px;
    margin: 50px auto;
}

.payment-box {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.1);
}

h1 {
    color: #0f4c75;
    margin-top: 0;
}

h2 {
    color: #0f4c75;
}

.summary {
    background: #f4f7f9;
    padding: 20px;
    border-radius: 8px;
    margin: 20px 0;
}

.row {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    margin: 10px 0;
}

.total {
    border-top: 1px solid #ddd;
    padding-top: 15px;
    margin-top: 15px;
    font-size: 20px;
}

.instructions {
    background: #eef7fc;
    border-left: 5px solid #0f4c75;
    padding: 20px;
    margin: 25px 0;
}

.instructions strong {
    color: #0f4c75;
}

.reference-form {
    margin-top: 25px;
}

.reference-form label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
}

.reference-form input {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
    margin-bottom: 15px;
}

button {
    width: 100%;
    padding: 13px;
    border: none;
    border-radius: 6px;
    background: #0f4c75;
    color: white;
    cursor: pointer;
    font-size: 16px;
}

button:hover {
    background: #3282b8;
}

.notice {
    margin-top: 20px;
    padding: 15px;
    background: #fff8e1;
    border-radius: 6px;
}

</style>

</head>

<body>

<div class="container">

<div class="payment-box">

<h1>Complete Your Payment</h1>

<p>
Hello
<strong>
<?php echo htmlspecialchars($booking["guest_name"]); ?>
</strong>
</p>

<div class="summary">

<div class="row">
<span>Booking Reference</span>

<strong>
WH-<?php echo str_pad(
    $booking["id"],
    6,
    "0",
    STR_PAD_LEFT
); ?>
</strong>
</div>

<div class="row">
<span>Room</span>

<strong>
<?php echo htmlspecialchars($booking["room_name"]); ?>
</strong>
</div>

<div class="row">
<span>Check-in</span>

<strong>
<?php echo htmlspecialchars($booking["check_in"]); ?>
</strong>
</div>

<div class="row">
<span>Check-out</span>

<strong>
<?php echo htmlspecialchars($booking["check_out"]); ?>
</strong>
</div>

<div class="row">
<span>Nights</span>

<strong>
<?php echo $nights; ?>
</strong>
</div>

<div class="row">
<span>Price per night</span>

<strong>
₦<?php echo number_format(
    $booking["price"],
    2
); ?>
</strong>
</div>

<div class="row total">

<span>Total Amount</span>

<strong>
₦<?php echo number_format(
    $total_amount,
    2
); ?>
</strong>

</div>

</div>


<div class="instructions">

<h2>Moniepoint Payment</h2>

<p>
Please make your payment using the hotel's
official Moniepoint Business account.
</p>

<p>
<strong>Account Name:</strong><br>
Chukwuma Ofudili
</p>

<p>
<strong>Account Number:</strong><br>
5103525004
</p>

<p>
<strong>Amount to Pay:</strong><br>
₦<?php echo number_format(
    $total_amount,
    2
); ?>
</p>

<p>
<strong>Important:</strong><br>
Please use your booking reference when making
the payment if Moniepoint allows a payment
description/reference.
</p>

</div>


<div class="notice">

<strong>
After making the payment:
</strong>

<p>
Enter your payment reference below and submit it.
Your booking will remain <strong>Pending</strong>
until the hotel administrator verifies the payment.
</p>

</div>


<form
    class="reference-form"
    action="submit_payment_reference.php"
    method="POST"
>

<input
    type="hidden"
    name="booking_id"
    value="<?php echo (int)$booking["id"]; ?>"
>

<label for="payment_reference">
Moniepoint Payment Reference
</label>

<input
    type="text"
    id="payment_reference"
    name="payment_reference"
    placeholder="Enter your payment reference"
    required
>

<button type="submit">
    Submit Payment Reference
</button>

</form>

</div>

</div>

</body>

</html>