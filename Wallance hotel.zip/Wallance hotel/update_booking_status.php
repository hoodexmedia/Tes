<?php

session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

include "config.php";

verify_csrf();

$id = (int)($_POST['id'] ?? 0);
$status = $_POST['booking_status'] ?? "";

$allowed_statuses = [
    "Pending",
    "Confirmed",
    "Cancelled",
    "Completed"
];

if ($id <= 0 || !in_array($status, $allowed_statuses, true)) {
    die("Invalid booking information.");
}

$stmt = $conn->prepare(
    "UPDATE bookings
     SET booking_status = ?
     WHERE id = ?"
);

$stmt->bind_param("si", $status, $id);

if ($stmt->execute()) {
    header("Location: view_bookings.php");
    exit();
}

echo "Unable to update booking.";

$stmt->close();
$conn->close();
?>