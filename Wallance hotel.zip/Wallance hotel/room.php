<?php

session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

include "config.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    verify_csrf();

    $room_name = trim(
        $_POST["room_name"] ?? ""
    );

    $room_type = trim(
        $_POST["room_type"] ?? ""
    );

    $price = (float)(
        $_POST["price"] ?? 0
    );

    $description = trim(
        $_POST["description"] ?? ""
    );

    $image = trim(
        $_POST["image"] ?? ""
    );
  $allowed_room_types = [
    "Standard",
    "Deluxe",
    "Executive"];

if (
    $room_name === "" ||
    !in_array(
        $room_type,
        $allowed_room_types,
        true
    ) ||
    $price <= 0
) {

    $message =
        "Please enter valid room information.";

} else {

    $sql = "
        INSERT INTO rooms
        (
            room_name,
            room_type,
            price,
            description,
            image
        )
        VALUES (?, ?, ?, ?, ?)
    ";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "ssdss",
        $room_name,
        $room_type,
        $price,
        $description,
        $image
    );

    if ($stmt->execute()) {

        $message =
            "Room added successfully!";

    } else {

        error_log(
            "Room insert failed: " .
            $stmt->error
        );

        $message =
            "Unable to add room.";
    }

    $stmt->close();
}
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add Hotel Room</title>

<style>

body{
    font-family:Arial,sans-serif;
    background:#f5f5f5;
}

.container{
    width:600px;
    margin:40px auto;
    background:white;
    padding:25px;
    border-radius:10px;
    box-shadow:0 0 10px rgba(0,0,0,.15);
}

h2{
    color:#0f4c75;
}

input,textarea,select{
    width:100%;
    padding:12px;
    margin:10px 0;
}

button{
    background:#0f4c75;
    color:white;
    border:none;
    padding:12px 20px;
    cursor:pointer;
}

.success{
    color:green;
    margin-bottom:15px;
}

</style>

</head>

<body>

<div class="container">

<h2>Add Hotel Room</h2>

<p class="success"><?php echo $message; ?></p>

<form method="POST">

<input
    type="hidden"
    name="csrf_token"
    value="<?php echo e(csrf_token()); ?>"
>

<input
type="text"
name="room_name"
placeholder="Room Name"
required>

<select name="room_type">

<option>Standard</option>

<option>Deluxe</option>

<option>Executive</option>

</select>

<input
type="number"
name="price"
placeholder="Price"
required>

<textarea
name="description"
placeholder="Description"
rows="5"></textarea>

<input
type="text"
name="image"
placeholder="Image filename e.g deluxe.jpg">

<button>Add Room</button>

</form>

</div>

</body>

</html>