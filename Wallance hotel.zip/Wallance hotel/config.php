<?php

/*
|--------------------------------------------------------------------------
| DATABASE CONFIGURATION
|--------------------------------------------------------------------------
|
| Change these values to match your MySQL/MariaDB installation.
|
*/

$host = "127.0.0.1";
$username = "root";
$password = "root";
$database = "Wallance hotel";


/*
|--------------------------------------------------------------------------
| DATABASE CONNECTION
|--------------------------------------------------------------------------
*/

$conn = new mysqli(
    $host,
    $username,
    $password,
    $database
);

if ($conn->connect_error) {

    error_log(
        "Database connection failed: " .
        $conn->connect_error
    );

    die("Unable to connect to the database.");
}


/*
|--------------------------------------------------------------------------
| CHARACTER SET
|--------------------------------------------------------------------------
*/

$conn->set_charset("utf8mb4");


/*
|--------------------------------------------------------------------------
| SESSION SECURITY
|--------------------------------------------------------------------------
|
| These settings must be applied before session_start().
|
*/

if (session_status() === PHP_SESSION_NONE) {

    ini_set(
        "session.cookie_httponly",
        "1"
    );

    ini_set(
        "session.cookie_samesite",
        "Lax"
    );

    /*
     * When the website is moved to HTTPS,
     * change this to 1.
     */
    ini_set(
        "session.cookie_secure",
        "0"
    );
}


/*
|--------------------------------------------------------------------------
| CSRF TOKEN
|--------------------------------------------------------------------------
|
| Creates one security token for the current session.
|
*/

function csrf_token()
{
    if (
        empty($_SESSION["csrf_token"])
    ) {

        $_SESSION["csrf_token"] =
            bin2hex(
                random_bytes(32)
            );
    }

    return $_SESSION["csrf_token"];
}


/*
|--------------------------------------------------------------------------
| CSRF VERIFICATION
|--------------------------------------------------------------------------
|
| Call this at the beginning of every POST action
| that changes data.
|
*/

function verify_csrf()
{
    $token =
        $_POST["csrf_token"] ?? "";

    if (
        empty($_SESSION["csrf_token"]) ||
        empty($token) ||
        !hash_equals(
            $_SESSION["csrf_token"],
            $token
        )
    ) {

        http_response_code(403);

        die("Invalid security token.");
    }
}


/*
|--------------------------------------------------------------------------
| HTML ESCAPING HELPER
|--------------------------------------------------------------------------
|
| This makes displaying database/user data safer.
|
*/

function e($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        "UTF-8"
    );
}
?>