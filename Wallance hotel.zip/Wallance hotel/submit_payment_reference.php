<?php

session_start();
include "config.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: Wallance.html");
    exit();
}

$booking_id = (int)($_POST["booking_id"] ?? 0);

$payment_reference = trim(
    $_POST["payment_reference"] ?? ""
);

if ($booking_id <= 0 || $payment_reference === "") {
    die("Please provide a valid payment reference.");
}

if (
    empty($_SESSION["booking_ids"]) ||
    !in_array($booking_id, $_SESSION["booking_ids"], true)
) {
    die("You do not have access to this booking.");
}

/*
 * Only allow payment reference to be submitted
 * for an existing unpaid booking.
 */

$stmt = $conn->prepare("
    SELECT id, payment_status
    FROM bookings
    WHERE id = ?
");

$stmt->bind_param("i", $booking_id);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows !== 1) {
    die("Booking not found.");
}

$booking = $result->fetch_assoc();

$stmt->close();

if ($booking["payment_status"] === "Paid") {
    die("This booking has already been paid.");
}


/*
 * Save the payment reference.
 *
 * The booking remains Unpaid/Pending until
 * the administrator manually verifies it.
 */

$stmt = $conn->prepare("
    UPDATE bookings
    SET payment_reference = ?
    WHERE id = ?
");

$stmt->bind_param(
    "si",
    $payment_reference,
    $booking_id
);

if ($stmt->execute()) {

    ?>

    <!DOCTYPE html>

    <html>

    <head>

    <meta charset="UTF-8">

    <title>Payment Submitted</title>

    <style>

    body {
        font-family: Arial, sans-serif;
        background: #f5f7f9;
    }

    .box {
        max-width: 550px;
        margin: 80px auto;
        background: white;
        padding: 40px;
        text-align: center;
        border-radius: 12px;
        box-shadow: 0 8px 25px rgba(0,0,0,.1);
    }

    h1 {
        color: #0f4c75;
    }

    a {
        display: inline-block;
        margin-top: 20px;
        padding: 12px 20px;
        background: #0f4c75;
        color: white;
        text-decoration: none;
        border-radius: 6px;
    }

    </style>

    </head>

    <body>

    <div class="box">

        <h1>Payment Reference Submitted</h1>

        <p>
            Thank you. Your payment reference has been
            submitted successfully.
        </p>

        <p>
            Your booking will remain
            <strong>Pending</strong>
            until the hotel verifies your payment.
        </p>

        <p>
            Booking Reference:
            <strong>
                WH-<?php echo str_pad(
                    $booking_id,
                    6,
                    "0",
                    STR_PAD_LEFT
                ); ?>
            </strong>
        </p>

        <a href="Wallance.html">
            Return to Website
        </a>

    </div>

    </body>

    </html>

    <?php

} else {

    die("Unable to submit payment reference.");

}

$stmt->close();
$conn->close();

?>