<?php

session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

include "config.php";

$result = $conn->query(
    "SELECT id, room_name, room_type, price, description, image
     FROM rooms
     ORDER BY id DESC"
);

if (!$result) {
    die("Unable to load rooms.");
}

?>

<!DOCTYPE html>

<html>

<head>

<title>Hotel Rooms</title>

<style>

table{

width:100%;

border-collapse:collapse;

}

th,td{

padding:12px;

border:1px solid #ddd;

}

th{

background:#0f4c75;

color:white;

}

img{

width:100px;

}

</style>

</head>

<body>

<h2>Available Rooms</h2>

<table>

<tr>

<th>ID</th>

<th>Name</th>

<th>Type</th>

<th>Price</th>

<th>Description</th>

<th>Image</th>

</tr>

<?php

while ($row = $result->fetch_assoc()) {

?>

<tr>

<td>
    <?php echo (int)$row["id"]; ?>
</td>

<td>
    <?php echo e($row["room_name"]); ?>
</td>

<td>
    <?php echo e($row["room_type"]); ?>
</td>

<td>
    ₦<?php echo number_format(
        (float)$row["price"],
        2
    ); ?>
</td>

<td>
    <?php echo e($row["description"]); ?>
</td>

<td>

<?php if (!empty($row["image"])): ?>

    <?php echo e($row["image"]); ?>

<?php else: ?>

    No image

<?php endif; ?>

</td>

</tr>

<?php

}

?>

</table>

</body>

</html>