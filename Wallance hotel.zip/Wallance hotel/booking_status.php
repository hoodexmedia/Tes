<?php

include "config.php";

$booking = null;
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $reference = trim($_POST["reference"] ?? "");
    $email = trim($_POST["email"] ?? "");

    // Convert WH-000001 into booking ID 1
    if (preg_match('/^WH-(\d+)$/i', $reference, $matches)) {
        $booking_id = (int)$matches[1];
    } else {
        $booking_id = 0;
    }

    if (
        $booking_id <= 0 ||
        !filter_var($email, FILTER_VALIDATE_EMAIL)
    ) {
        $error = "Please enter a valid booking reference and email address.";
    } else {

        $stmt = $conn->prepare("
            SELECT
                b.id,
                b.guest_name,
                b.email,
                b.check_in,
                b.check_out,
                b.guests,
                b.booking_status,
                b.payment_status,
                b.payment_reference,
                b.booking_date,
                r.room_name,
                r.room_type,
                r.price
            FROM bookings b
            INNER JOIN rooms r ON b.room_id = r.id
            WHERE b.id = ?
            AND b.email = ?
        ");

        $stmt->bind_param(
            "is",
            $booking_id,
            $email
        );

        $stmt->execute();

        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $booking = $result->fetch_assoc();
        } else {
            $error = "No booking was found with those details.";
        }

        $stmt->close();
    }
}

$conn->close();

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Check Booking | Wallance Hotel</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f5f7f9;
    color: #333;
}

.container {
    width: 90%;
    max-width: 650px;
    margin: 50px auto;
}

.box {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 8px 25px rgba(0,0,0,.1);
}

h1 {
    color: #0f4c75;
}

label {
    display: block;
    margin-top: 15px;
    margin-bottom: 7px;
    font-weight: bold;
}

input {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 6px;
}

button {
    width: 100%;
    margin-top: 20px;
    padding: 13px;
    border: none;
    border-radius: 6px;
    background: #0f4c75;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #3282b8;
}

.error {
    background: #ffecec;
    color: #b00020;
    padding: 12px;
    border-radius: 6px;
}

.details {
    margin-top: 25px;
}

.row {
    display: flex;
    justify-content: space-between;
    gap: 20px;
    padding: 12px 0;
    border-bottom: 1px solid #eee;
}

.status {
    padding: 5px 10px;
    border-radius: 5px;
    font-weight: bold;
}

.pending {
    background: #fff3cd;
    color: #856404;
}

.confirmed {
    background: #d4edda;
    color: #155724;
}

.cancelled {
    background: #f8d7da;
    color: #721c24;
}

.completed {
    background: #d1ecf1;
    color: #0c5460;
}

.paid {
    color: green;
    font-weight: bold;
}

.unpaid {
    color: #b00020;
    font-weight: bold;
}

</style>

</head>

<body>

<div class="container">

<div class="box">

<h1>Check Your Booking</h1>

<p>
Enter your booking reference and the email address
used when making the reservation.
</p>

<?php if ($error): ?>

    <p class="error">
        <?php echo htmlspecialchars($error); ?>
    </p>

<?php endif; ?>


<form method="POST">

<label for="reference">
Booking Reference
</label>

<input
    type="text"
    id="reference"
    name="reference"
    placeholder="WH-000001"
    required
>

<label for="email">
Email Address
</label>

<input
    type="email"
    id="email"
    name="email"
    placeholder="your@email.com"
    required
>

<button type="submit">
    Check Booking
</button>

</form>


<?php if ($booking): ?>

<div class="details">

<h2>
Booking Details
</h2>

<div class="row">

<span>Reference</span>

<strong>
WH-<?php echo str_pad(
    $booking["id"],
    6,
    "0",
    STR_PAD_LEFT
); ?>
</strong>

</div>


<div class="row">

<span>Guest</span>

<strong>
<?php echo htmlspecialchars(
    $booking["guest_name"]
); ?>
</strong>

</div>


<div class="row">

<span>Room</span>

<strong>
<?php echo htmlspecialchars(
    $booking["room_name"]
); ?>
</strong>

</div>


<div class="row">

<span>Room Type</span>

<strong>
<?php echo htmlspecialchars(
    $booking["room_type"]
); ?>
</strong>

</div>


<div class="row">

<span>Check-in</span>

<strong>
<?php echo htmlspecialchars(
    $booking["check_in"]
); ?>
</strong>

</div>


<div class="row">

<span>Check-out</span>

<strong>
<?php echo htmlspecialchars(
    $booking["check_out"]
); ?>
</strong>

</div>


<div class="row">

<span>Guests</span>

<strong>
<?php echo (int)$booking["guests"]; ?>
</strong>

</div>


<div class="row">

<span>Booking Status</span>

<strong class="status
<?php
echo strtolower(
    $booking["booking_status"]
);
?>
">

<?php echo htmlspecialchars(
    $booking["booking_status"]
); ?>

</strong>

</div>


<div class="row">

<span>Payment Status</span>

<strong class="<?php
echo strtolower(
    $booking["payment_status"]
);
?>">

<?php echo htmlspecialchars(
    $booking["payment_status"]
); ?>

</strong>

</div>


<?php if (
    !empty($booking["payment_reference"])
): ?>

<div class="row">

<span>Payment Reference</span>

<strong>
<?php echo htmlspecialchars(
    $booking["payment_reference"]
); ?>
</strong>

</div>

<?php endif; ?>


<div class="row">

<span>Booking Date</span>

<strong>
<?php echo htmlspecialchars(
    $booking["booking_date"]
); ?>
</strong>

</div>

</div>

<?php endif; ?>

</div>

</div>

</body>

</html>