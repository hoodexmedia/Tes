<?php
session_start();

if(!isset($_SESSION['admin'])){

header("Location: login.php");

exit();

}

include "config.php";

$rooms = $conn->query("SELECT * FROM rooms")->num_rows;
$bookings = $conn->query("SELECT * FROM bookings")->num_rows;
$contacts = $conn->query("SELECT * FROM contacts")->num_rows;
?>

<!DOCTYPE html>

<html>

<head>

<title>Dashboard</title>

<style>

body{

font-family:Arial;

margin:0;

background:#f5f5f5;

}

.header{

background:#0f4c75;

color:white;

padding:20px;

}

.cards{

display:flex;

flex-wrap:wrap;

gap:20px;

padding:20px;

}

.card{

background:white;

padding:25px;

width:220px;

box-shadow:0 0 10px rgba(0,0,0,.1);

border-radius:10px;

text-align:center;

}

a{

text-decoration:none;

}

.menu{

padding:20px;

}

.menu a{

display:block;

padding:10px;

background:#3282b8;

color:white;

margin-bottom:10px;

}

</style>

</head>

<body>

<div class="header">

<h2>
    Welcome
    <?php echo htmlspecialchars($_SESSION["admin"]); ?>
</h2>

</div>

<div class="cards">

<div class="card">

<h3><?php echo $rooms; ?></h3>

<p>Rooms</p>

</div>

<div class="card">

<h3><?php echo $bookings; ?></h3>

<p>Bookings</p>

</div>

<div class="card">

<h3><?php echo $contacts; ?></h3>

<p>Messages</p>

</div>

</div>

<div class="menu">

<a href="room.php">🛏 Add Room</a>

<a href="view_rooms.php">🏨 View Rooms</a>

<a href="view_bookings.php">📅 View Bookings</a>

<a href="logout.php">🚪 Logout</a>

</div>

</body>

</html>