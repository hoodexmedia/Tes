<?php
session_start();
include "config.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: Wallance.html");
    exit();
}

$guest_name = trim($_POST["guest_name"] ?? "");
$email      = trim($_POST["email"] ?? "");
$phone      = trim($_POST["phone"] ?? "");
$room_id    = (int)($_POST["room_id"] ?? 0);
$check_in   = $_POST["check_in"] ?? "";
$check_out  = $_POST["check_out"] ?? "";
$guests     = (int)($_POST["guests"] ?? 0);

/* Validate required fields */
if (
    $guest_name === "" ||
    !filter_var($email, FILTER_VALIDATE_EMAIL) ||
    $phone === "" ||
    $room_id <= 0 ||
    $check_in === "" ||
    $check_out === "" ||
    $guests <= 0
) {
    die("Please provide valid booking information.");
}

/* Validate dates */
$today = date("Y-m-d");

if ($check_in < $today) {
    die("Check-in date cannot be in the past.");
}

if ($check_out <= $check_in) {
    die("Check-out date must be after check-in date.");
}

/* Check that the room exists */
$stmt = $conn->prepare(
    "SELECT id, room_name, price
     FROM rooms
     WHERE id = ? AND status = 'Available'"
);

$stmt->bind_param("i", $room_id);
$stmt->execute();

$room = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$room) {
    die("The selected room is not available.");
}

/*
   Check for overlapping bookings.

   Existing booking overlaps when:

   existing check-in < requested check-out
   AND
   existing check-out > requested check-in
*/
$stmt = $conn->prepare(
    "SELECT id
 FROM bookings
 WHERE room_id = ?
 AND check_in < ?
 AND check_out > ?
 AND booking_status IN ('Pending', 'Confirmed')"
);

$stmt->bind_param(
    "iss",
    $room_id,
    $check_out,
    $check_in
);

$stmt->execute();

$existing = $stmt->get_result();

if ($existing->num_rows > 0) {
    $stmt->close();
    die("Sorry, this room is already booked for the selected dates.");
}

$stmt->close();

/* Create booking */
$stmt = $conn->prepare(
    "INSERT INTO bookings
    (guest_name, email, phone, room_id, check_in, check_out, guests)
    VALUES (?, ?, ?, ?, ?, ?, ?)"
);

$stmt->bind_param(
    "sssissi",
    $guest_name,
    $email,
    $phone,
    $room_id,
    $check_in,
    $check_out,
    $guests
);

if (!$stmt->execute()) {
    die("Unable to complete the booking. Please try again.");
}

$booking_id = $stmt->insert_id;

$stmt->close();
$conn->close();

// Remember this booking so payment.php can verify ownership
$_SESSION["booking_ids"][] = $booking_id;

// Redirect to payment page
header("Location: payment.php?booking_id=" . $booking_id);
exit();
?>
