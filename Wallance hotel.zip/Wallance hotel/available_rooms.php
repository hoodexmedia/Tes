<?php
include "config.php";

$check_in = $_GET["check_in"] ?? "";
$check_out = $_GET["check_out"] ?? "";

if ($check_in === "" || $check_out === "") {
    echo '<option value="">Select your dates first</option>';
    exit;
}

if ($check_out <= $check_in) {
    echo '<option value="">Check-out must be after check-in</option>';
    exit;
}

/*
   Find rooms that do NOT have an overlapping booking.

   An existing booking overlaps when:
   existing check-in < requested check-out
   AND
   existing check-out > requested check-in
*/

$sql = "
    SELECT r.id, r.room_name, r.room_type, r.price
    FROM rooms r
    WHERE r.status = 'Available'
    AND NOT EXISTS (
        SELECT 1
        FROM bookings b
        WHERE b.room_id = r.id
AND b.check_in < ?
AND b.check_out > ?
AND b.booking_status IN ('Pending', 'Confirmed')
    )
    ORDER BY r.price ASC
";

$stmt = $conn->prepare($sql);

$stmt->bind_param(
    "ss",
    $check_out,
    $check_in
);

$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {

    echo '<option value="">No rooms available for these dates</option>';

} else {

    echo '<option value="">Select a room</option>';

    while ($room = $result->fetch_assoc()) {

        echo '<option value="' . (int)$room["id"] . '">'
            . htmlspecialchars($room["room_name"])
            . ' - ₦'
            . number_format($room["price"], 2)
            . ' / night'
            . '</option>';
    }
}

$stmt->close();
$conn->close();
?>