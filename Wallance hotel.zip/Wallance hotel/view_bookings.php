<?php

session_start();

if (!isset($_SESSION["admin"])) {
    header("Location: login.php");
    exit();
}

include "config.php";

$sql = "
    SELECT
        b.id,
        b.guest_name,
        b.email,
        b.phone,
        b.check_in,
        b.check_out,
        b.guests,
        b.booking_status,
        b.payment_status,
        b.payment_reference,
        b.booking_date,
        r.room_name
    FROM bookings b
    INNER JOIN rooms r ON b.room_id = r.id
    ORDER BY b.booking_date DESC
";

$result = $conn->query($sql);

if (!$result) {
    die("Unable to load bookings.");
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>Bookings | Wallance Hotel</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f5f7f9;
}

.container {
    width: 95%;
    max-width: 1500px;
    margin: 30px auto;
}

h1 {
    color: #0f4c75;
}

.table-wrapper {
    overflow-x: auto;
    background: white;
    border-radius: 10px;
    box-shadow: 0 5px 20px rgba(0,0,0,.08);
}

table {
    width: 100%;
    border-collapse: collapse;
    min-width: 1200px;
}

th,
td {
    padding: 12px;
    border-bottom: 1px solid #eee;
    text-align: left;
    vertical-align: middle;
}

th {
    background: #0f4c75;
    color: white;
}

tr:hover {
    background: #f8fafc;
}

button,
.btn {
    padding: 8px 12px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    text-decoration: none;
    display: inline-block;
}

button {
    background: #0f4c75;
    color: white;
}

.delete {
    background: #b00020;
    color: white;
}

.status-form {
    display: flex;
    gap: 5px;
}

select {
    padding: 8px;
}

.paid {
    color: green;
    font-weight: bold;
}

.unpaid {
    color: #b00020;
    font-weight: bold;
}

.reference {
    font-family: monospace;
}

.top-link {
    display: inline-block;
    margin-bottom: 20px;
    color: #0f4c75;
    text-decoration: none;
}

</style>

</head>

<body>

<div class="container">

<a
    class="top-link"
    href="dashboard.php"
>
    ← Back to Dashboard
</a>

<h1>Hotel Bookings</h1>

<div class="table-wrapper">

<table>

<thead>

<tr>

<th>ID</th>
<th>Guest</th>
<th>Email</th>
<th>Phone</th>
<th>Room</th>
<th>Check-in</th>
<th>Check-out</th>
<th>Guests</th>
<th>Booking Date</th>
<th>Payment Reference</th>
<th>Payment Status</th>
<th>Booking Status</th>
<th>Actions</th>

</tr>

</thead>

<tbody>

<?php if ($result->num_rows > 0): ?>

<?php while ($row = $result->fetch_assoc()): ?>

<tr>

<td>
    <?php echo (int)$row["id"]; ?>
</td>

<td>
    <?php echo htmlspecialchars($row["guest_name"]); ?>
</td>

<td>
    <?php echo htmlspecialchars($row["email"]); ?>
</td>

<td>
    <?php echo htmlspecialchars($row["phone"]); ?>
</td>

<td>
    <?php echo htmlspecialchars($row["room_name"]); ?>
</td>

<td>
    <?php echo htmlspecialchars($row["check_in"]); ?>
</td>

<td>
    <?php echo htmlspecialchars($row["check_out"]); ?>
</td>

<td>
    <?php echo (int)$row["guests"]; ?>
</td>

<td>
    <?php echo htmlspecialchars($row["booking_date"]); ?>
</td>

<td class="reference">

<?php

if (!empty($row["payment_reference"])) {

    echo htmlspecialchars(
        $row["payment_reference"]
    );

} else {

    echo "Not submitted";

}

?>

</td>

<td>

<?php if ($row["payment_status"] === "Paid"): ?>

    <span class="paid">
        ✓ Paid
    </span>

<?php else: ?>

    <span class="unpaid">
        Unpaid
    </span>

<?php endif; ?>

</td>

<td>

<form
    class="status-form"
    action="update_booking_status.php"
    method="POST"
>
  <input
    type="hidden"
    name="csrf_token"
    value="<?php echo e(csrf_token()); ?>"
>

<input
    type="hidden"
    name="id"
    value="<?php echo (int)$row["id"]; ?>"
>

<select name="booking_status">

<option
    value="Pending"
    <?php
    echo $row["booking_status"] === "Pending"
        ? "selected"
        : "";
    ?>
>
    Pending
</option>

<option
    value="Confirmed"
    <?php
    echo $row["booking_status"] === "Confirmed"
        ? "selected"
        : "";
    ?>
>
    Confirmed
</option>

<option
    value="Cancelled"
    <?php
    echo $row["booking_status"] === "Cancelled"
        ? "selected"
        : "";
    ?>
>
    Cancelled
</option>

<option
    value="Completed"
    <?php
    echo $row["booking_status"] === "Completed"
        ? "selected"
        : "";
    ?>
>
    Completed
</option>

</select>

<button type="submit">
    Update
</button>

</form>

</td>

<td>

<?php if ($row["payment_status"] !== "Paid"): ?>

<form
    action="confirm_payment.php"
    method="POST"
    onsubmit="return confirm('Have you verified this payment in Moniepoint?');"
>
  <input
    type="hidden"
    name="csrf_token"
    value="<?php echo e(csrf_token()); ?>"
>

<input
    type="hidden"
    name="booking_id"
    value="<?php echo (int)$row["id"]; ?>"
>

<button type="submit">
    Confirm Payment
</button>

</form>

<?php endif; ?>

<br><br>

<form
    action="delete_bookings.php"
    method="POST"
    onsubmit="return confirm('Delete this booking permanently?');"
>

<input
    type="hidden"
    name="booking_id"
    value="<?php echo (int)$row["id"]; ?>"
>

<input
    type="hidden"
    name="csrf_token"
    value="<?php echo e(csrf_token()); ?>"
>

<button
    type="submit"
    class="delete"
>
    Delete
</button>

</form>

</td>

</tr>

<?php endwhile; ?>

<?php else: ?>

<tr>

<td colspan="13">
    No bookings found.
</td>

</tr>

<?php endif; ?>

</tbody>

</table>

</div>

</div>

</body>

</html>

<?php

$conn->close();

?>